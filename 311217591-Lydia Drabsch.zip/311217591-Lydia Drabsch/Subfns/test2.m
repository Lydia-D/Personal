a = [1,2,2];
if sum(a == 2) && sum(a~=3)
    7

    endons_i
    